# -*- mode: python ; coding: utf-8 -*-

added_files=[
('C:/Users/谭省忠/Desktop/code(1)/UI', 'UI')
("C:\\Users\\谭省忠\\Desktop\\code(1)\\img_prc","img_prc")
(("C:\\Users\\谭省忠\\PycharmProjects\\pythonProject\\venv\\Lib\\site-packages",'.'))]

a = Analysis(
    ['main.py',
    'img_prc/bullet_hole_detect.py',
    'img_prc/circle.py',
    'img_prc/filter.py',
    'img_prc/img_process.py',
    'img_prc/judge_rings.py',
    'img_prc/utils.py',
    'img_prc/recommendation.py',
    'UI/detect.py',
    'UI/login.py',
    'UI/Register.py'],
    pathex=[],
    binaries=[],
    datas=[("C:\\Users\\谭省忠\\Desktop\\code(1)\\images",'images')],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='main',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='main',
)

import cv2
import numpy as np
import img_prc.filter
from img_prc.filter import apply_closing_application,apply_gaussian_blur,apply_opening_operation

def detect_and_average_circles(img):
    # Resize the image for faster processing
    img = cv2.resize(img, None, fx=0.5, fy=0.5)
    GrayImage = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    GrayImage = cv2.blur(GrayImage, (7, 7))

    # Apply Hough Circle Transform
    circles = cv2.HoughCircles(GrayImage, cv2.HOUGH_GRADIENT, 0.5, minDist=50, param1=8, param2=20, minRadius=25, maxRadius=45)

    if circles is not None:
        circles = np.uint16(np.around(circles))
        center_points = []
        radii = []

        # Collect all circle center coordinates and radius
        for i in circles[0, :]:
            center_points.append([i[0], i[1]])
            radii.append(i[2])

        # Calculate average center position and radius
        avg_center = np.mean(center_points, axis=0).astype(int)
        avg_radius = int(np.mean(radii))

        # Draw average circle and its center on the image
        cv2.circle(img, tuple(avg_center), avg_radius, (0, 255, 0), 2)
        cv2.circle(img, tuple(avg_center), 5, (0, 0, 255), -1)

        # Display the result with the average circle
        img = cv2.resize(img, (600, 600))
        cv2.imshow("Detected Circles and Average Circle", img)

        cv2.imwrite("C:/photo/9.jpg", img)
        cv2.waitKey(0)
        cv2.destroyAllWindows()

    else:
        print("No circles detected.")

    # Return the average circle's parameters as displayed on the image
    return tuple(avg_center*2), avg_radius*2
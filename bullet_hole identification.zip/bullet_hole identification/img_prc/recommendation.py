import math


def process_input(shots_coordinates):
    """
    处理输入的弹孔坐标列表，计算平均坐标和方差。

    :param shots_coordinates: 弹孔坐标列表，如[[(x1, y1), (x2, y2), ...]]
    :return: 平均坐标(mean_x, mean_y), 方差(variance)
    """
    # 计算平均x和y坐标
    mean_x = sum(x for x, y in shots_coordinates) / len(shots_coordinates)
    mean_y = sum(y for x, y in shots_coordinates) / len(shots_coordinates)

    # 计算方差
    variance = sum((x - mean_x) ** 2 + (y - mean_y) ** 2 for x, y in shots_coordinates) / len(shots_coordinates)

    return mean_x, mean_y, variance

def calculate_variance_and_direction(shots_coordinates, target_center):
    """
    计算弹着点的方差及相对于靶心的方向偏离。

    :param shots_coordinates: 弹孔坐标列表
    :param target_center: 靶心坐标，默认为(0, 0)
    :return: 方差(variance), 平均偏移角度(mean_direction_deviation)
    """
    # 已有计算方差的代码
    mean_x, mean_y, variance = process_input(shots_coordinates)

    # 计算每个弹着点相对于靶心的方向偏离（简化处理，仅示例）
    total_angle_deviation = 0
    for x, y in shots_coordinates:
        dx = x - target_center[0]
        dy = y - target_center[1]
        # 假设靶心向上为0度，顺时针方向角度增加
        angle = math.degrees(math.atan2(dy, dx)) % 360
        # 简化处理，假设目标是尽量垂直或水平射击，偏离计算为与90或0度的差
        ideal_angle = 90 if dx == 0 else 0  # 简化处理，未考虑所有情况
        angle_deviation = min(abs(angle - ideal_angle), abs(angle - (ideal_angle + 180)))
        total_angle_deviation += angle_deviation

    mean_direction_deviation = total_angle_deviation / len(shots_coordinates)

    return variance, mean_direction_deviation


def evaluate_performance_refined(ring_score, variance, direction_deviation, variance_thresholds=(100, 200),
                                 direction_thresholds=(10, 20)):
    """
    细化考虑方差和方向偏离给出更具体的评价建议。

    :param ring_score: 环数
    :param variance: 方差，衡量射击点的分散程度
    :param direction_deviation: 平均方向偏离度数
    :param variance_thresholds: 方差的多个阈值，用于分层评价
    :param direction_thresholds: 方向偏离的多个阈值，用于分层评价
    :return: 综合评价建议
    """
    if ring_score == 50:
        return "成绩卓越，保持稳定发挥！"

    # 方差评价层次
    for i, var_thresh in enumerate(variance_thresholds):
        if variance <= var_thresh:
            variance_level = i + 1
            break
    else:
        variance_level = len(variance_thresholds)

    # 方向偏离评价层次
    for i, dir_thresh in enumerate(direction_thresholds):
        if direction_deviation <= dir_thresh:
            direction_level = i + 1
            break
    else:
        direction_level = len(direction_thresholds)

    # 综合评价
    if ring_score >= 40:
        if variance_level <= 1 and direction_level <= 1:
            return "射击极其稳定，注意微调以挑战更高环数。"
        elif variance_level == 1 and direction_level > 1:
            return "射击稳定性佳，但存在方向性偏差，检查瞄准和据枪姿态。"
        elif variance_level > 1 and direction_level <= 1:
            return "射击点稍显分散，加强据枪稳定性和呼吸控制。"
        else:
            return "注意射击稳定性与方向控制，加强基础训练。"
    elif 30 <= ring_score < 40:
        return f"成绩中等，需加强{['稳定性', '方向控制'][direction_level - 1]}，确保瞄准具准确无误。"
    else:
        return "成绩有待提升，全面复习射击基础，专注于精准度和稳定性训练。"


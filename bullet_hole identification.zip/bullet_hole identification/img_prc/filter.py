import cv2
import numpy as np


def apply_closing_application(img):   #闭运算
# 设置核
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(3,3))
# 闭运算
    filter_img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, kernel)

    cv2.waitKey(0)
    return filter_img


def apply_gaussian_blur(image, kernel_size=(5, 5), sigmaX=0):   #高斯滤波
    blurred_image = cv2.GaussianBlur(image, kernel_size, sigmaX)
    return blurred_image


def apply_opening_operation(image, kernel_size=(3, 3)): #开运算

    # 创建一个结构元素（核）
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, kernel_size)

    # 应用腐蚀操作
    eroded_image = cv2.erode(image, kernel)

    # 应用膨胀操作，得到开运算结果
    opened_image = cv2.dilate(eroded_image, kernel)
    cv2.waitKey(0)

    return opened_image



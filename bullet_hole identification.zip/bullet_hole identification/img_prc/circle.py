import cv2
import numpy as np
import img_prc.filter
from img_prc.filter import apply_closing_application,apply_gaussian_blur,apply_opening_operation

def detect_and_average_circles(img):
    # Resize the image for faster processing
    img = cv2.resize(img, None, fx=0.5, fy=0.5)
    GrayImage = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    GrayImage = cv2.blur(GrayImage, (7, 7))

    # Apply Hough Circle Transform
    circles = cv2.HoughCircles(GrayImage, cv2.HOUGH_GRADIENT, 0.5, minDist=60, param1=20, param2=40, minRadius=20, maxRadius=100)

    if circles is not None:
        circles = np.uint16(np.around(circles))
        center_points = []
        radii = []

        # Collect all circle center coordinates and radius
        for i in circles[0, :]:
            center_points.append([i[0], i[1]])
            radii.append(i[2])

        # Calculate average center position and radius
        avg_center = np.mean(center_points, axis=0).astype(int)
        avg_radius = int(np.mean(radii))

        # Draw average circle and its center on the image
        cv2.circle(img, tuple(avg_center), avg_radius, (0, 255, 0), 2)
        cv2.circle(img, tuple(avg_center), 5, (0, 0, 255), -1)

        img = cv2.resize(img, (1200, 1200))

        cv2.imwrite("C:/photo/circle.jpg", img)
        cv2.waitKey(0)
        cv2.destroyAllWindows()

    else:
        print("No circles detected.")

    # Return the average circle's parameters as displayed on the image
    return tuple(avg_center*2), avg_radius*2




# def detect_and_average_circles(image):
#     """
#     检测给定RGB图像中的圆形，计算所有检测到的圆的平均圆心坐标和平均半径，
#     并在图像上绘制平均圆。最后返回这两个值。
#
#     参数:
#     image (numpy.ndarray): 输入的RGB图像。
#
#     返回:
#     tuple: 包含平均圆心坐标(x_avg, y_avg)和平均半径r_avg的元组。
#     """
#     # 将图像转换为灰度图
#     gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
#
#     # 应用高斯模糊以减少噪声
#     gray = cv2.GaussianBlur(gray, (5, 5), 0)
#
#     # 使用HoughCircles方法检测圆形
#     circles = cv2.HoughCircles(gray, cv2.HOUGH_GRADIENT, 1, minDist=30,
#                                param1=40, param2=40, minRadius=10, maxRadius=50)
#
#     # 确保找到了一些圆
#     if circles is not None:
#         # 将检测到的圆的坐标和半径从浮点数转换为整数
#         circles = np.round(circles[0, :]).astype("int")
#
#         # 收集所有圆心坐标和半径
#         centers = circles[:, :2]
#         radii = circles[:, 2]
#
#         # 计算平均圆心坐标和平均半径
#         center_avg = np.mean(centers, axis=0).astype("int")
#         radius_avg = int(np.mean(radii))
#
#         # 在图像上绘制平均圆
#         cv2.circle(image, tuple(center_avg), radius_avg, (0, 255, 0), 2)
#         cv2.circle(image, tuple(center_avg), 2, (0, 0, 255), 3)
#
#         # 显示带有平均圆的图像
#         cv2.imshow("Image with Average Circle", image)
#         cv2.waitKey(0)
#         cv2.destroyAllWindows()
#
#         return (center_avg[0], center_avg[1]), radius_avg
#     else:
#         # 如果没有检测到圆，返回None或默认值
#         return None, None



# image_path = r"C:\Users\Administrator\Desktop\professional design\datasets\640.jpg"
# img = cv2.imread(image_path,1)
#
# if img is None:
#     print("Error: Image not found or unable to read.")
# filter_img = apply_gaussian_blur(apply_closing_application(apply_opening_operation(img)))
# center,radius = detect_and_average_circles(filter_img)
# print("Average Center Coordinates:", center)
# print("Average Radius:", radius)
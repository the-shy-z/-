import cv2
import numpy as np

def start(img):
    # r, c, _ = img.shape
    # img = cv2.resize(img, (int(c / 2), int(r / 2)))
    grayImage = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    imageHeight, imageWidth = grayImage.shape[0:2]
    #print(imageWidth, ", ", imageHeight)
    # 进行一次自适应阈值提升边界识别度，参数可根据不同图片适当调整，特别是左后一个参数
    binaryImage = cv2.adaptiveThreshold(grayImage, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 11, 2)
    binaryImage = ~binaryImage
    cv2.imwrite("C:/photo/bI.jpg", binaryImage)
    # 这里我本来准备进行形态学操作的，可根据图片质量来取舍是否需要进行该操作，有些图片操作会好点
    # kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, 1))
    # binaryImage = cv2.erode(binaryImage, kernel, iterations=1)
    # binaryImage = cv2.dilate(binaryImage, kernel, iterations=1)

    # 查找轮廓
    contours, hierarchy = cv2.findContours(~binaryImage, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    # 画轮廓
    image1=img.copy()
    cv2.drawContours(image1, contours, -1, (0, 0, 255), 1)
    # cv2.imshow("Contours", image1)
    # cv2.waitKey(0)
    cv2.imwrite("C:/photo/contours.jpg", image1)
    #print(len(contours))
    for i in range(len(contours)):
        arclen = cv2.arcLength(contours[i], True)
        epsilon = max(3, int(arclen * 0.02))
        # 每个轮廓进行多边形拟合，计算其面积，边数，周长等信息
        approx = cv2.approxPolyDP(contours[i], epsilon, True)
        # 计算面积
        area = cv2.contourArea(contours[i])

        # 计算最小包围矩阵，这里没太多印象，要不要无所谓
        rect = cv2.minAreaRect(contours[i])

        h = int(rect[1][0])
        w = int(rect[1][1])
        if min(h, w) == 0:
            rotion = 0
        else:
            rotion = max(h, w) / min((h, w))
        imageArea = imageWidth * imageHeight
        # 这里是删选轮廓的判断，长款比太大的不要，面积太小的不要，太大的也不要，如果是想得到四边形，那么后面的shap[0]就是去这个轮廓的边数，我这里取四边形，满足条件的轮廓画出来
        if rotion < 10 and area > imageArea * 0.2 and area < imageWidth * imageHeight * 0.90 and approx.shape[0] == 4:
            # 对满足条件的轮廓画出轮廓的拟合多边形
            image2 = img.copy()
            cv2.polylines(image2, [approx], True, (0, 255, 0), 1)
            cv2.circle(image2, (approx[0][0][0], approx[0][0][1]), 3, (0, 0, 255), 2)
            cv2.putText(image2, str(1), (approx[0][0][0], approx[0][0][1]), cv2.FONT_HERSHEY_PLAIN,
                        1.0, (0, 0, 0), thickness=1)
            cv2.circle(image2, (approx[1][0][0], approx[1][0][1]), 3, (0, 0, 255), 2)
            cv2.putText(image2, str(2), (approx[1][0][0], approx[1][0][1]), cv2.FONT_HERSHEY_PLAIN,
                        1.0, (0, 0, 0), thickness=1)
            cv2.circle(image2, (approx[2][0][0], approx[2][0][1]), 3, (0, 0, 255), 2)
            cv2.putText(image2, str(3), (approx[2][0][0], approx[2][0][1]), cv2.FONT_HERSHEY_PLAIN,
                        1.0, (0, 0, 0), thickness=1)
            cv2.circle(image2, (approx[3][0][0], approx[3][0][1]), 3, (0, 0, 255), 2)
            cv2.putText(image2, str(4), (approx[3][0][0], approx[3][0][1]), cv2.FONT_HERSHEY_PLAIN,
                        1.0, (0, 0, 0), thickness=1)
            cv2.imwrite("C:/photo/contours1.jpg",image2)
            dot=[[int(approx[2][0][0]),int(approx[2][0][1])],
                 [int(approx[1][0][0]),int(approx[1][0][1])],
                 [int(approx[3][0][0]),int(approx[3][0][1])],
                 [int(approx[0][0][0]),int(approx[0][0][1])]]
            return dot

# 图片校正
def Image_correction(img, dot0):
    # r, c, _ = img.shape
    # img = cv2.resize(img, (int(c / 2), int(r / 2)))
    # 缩小图片
    # r, c, _ = img.shape
    # img = cv2.resize(img, (int(c / 2), int(r / 2)))
    # 初始化矩形四点坐标
    rect = np.zeros((4, 2), dtype="float32")
    # 将dot0转换为numpy数组
    dot0 = np.array(dot0)
    # 打印dot0
    # print(dot0)
    # 获取左上角和右下角坐标点
    s = dot0.sum(axis=1)
    rect[0] = dot0[np.argmin(s)]
    rect[2] = dot0[np.argmax(s)]

    # 分别计算左上角和右下角的离散差值
    diff = np.diff(dot0, axis=1)
    rect[1] = dot0[np.argmin(diff)]
    rect[3] = dot0[np.argmax(diff)]
    # 打印rect
    # print(rect)
    # 获取矩形四个顶点坐标
    (tl, tr, br, bl) = rect
    # 计算矩形宽度
    widthA = np.sqrt(((br[0] - bl[0]) ** 2) + ((br[1] - bl[1]) ** 2))
    widthB = np.sqrt(((tr[0] - tl[0]) ** 2) + ((tr[1] - tl[1]) ** 2))
    # 获取矩形最大宽度
    maxWidth = max(int(widthA), int(widthB))
    # 计算新图片的高度值，选取垂直差值的最大值
    heightA = np.sqrt(((tr[0] - br[0]) ** 2) + ((tr[1] - br[1]) ** 2))
    heightB = np.sqrt(((tl[0] - bl[0]) ** 2) + ((tl[1] - bl[1]) ** 2))
    # 获取新图片最大高度
    maxHeight = max(int(heightA), int(heightB))

    # 构建新图片的4个坐标点
    dst = np.array([
        [0, 0],
        [maxWidth - 1, 0],
        [maxWidth - 1, maxHeight - 1],
        [0, maxHeight - 1]], dtype="float32")
    # 获取仿射变换矩阵并应用它
    M = cv2.getPerspectiveTransform(rect, dst)
    # 进行仿射变换
    warped = cv2.warpPerspective(img, M, (maxWidth, maxHeight))
    warped=cv2.resize(warped,(1200,1200))
    return warped,M,maxWidth,maxHeight

def order_points_simple(points):
    # 将点按y坐标排序，y坐标小的排在前面
    points = sorted(points, key=lambda p: (p[1], p[0]))

    # 确保按照左下、右下、右上、左上顺序排列
    if points[0][0] < points[1][0]:
        ordered = [points[0], points[1], points[3], points[2]]
    else:
        ordered = [points[1], points[0], points[2], points[3]]

    return ordered
if __name__ == "__main__":
    imagePath = "C:/photo/5.jpg"
    img = cv2.imread(imagePath)
    dot=start(img)
    print(dot)
    #img=shot_new(imagePath, dot)

    warped=Image_correction(img,dot)

    # 结果显示
    cv2.imshow("Original", img)
    cv2.imshow("Warped", warped)
    cv2.imwrite("C:/photo/8.jpg", warped)
    cv2.waitKey(0)
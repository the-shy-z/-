import cv2
import numpy as np
import math

# image_path = r"C:\Users\Administrator\Desktop\professional design\datasets\2f6e98d97f3618c65cc831b219ac61c.png"  # 替换为你的图像路径
# img = cv2.imread(image_path)
# if img is None:
#     raise ValueError("Image not found or unable to load.")
# image_hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)


def judge_rings(inImg,x,y, center_x,center_y,standard_distance):
    distance = math.sqrt((x - center_x) ** 2 + (y - center_y) ** 2)
    if 0 <= distance <= standard_distance:
        return 10
    elif standard_distance< distance <= 2*standard_distance:
        return 9
    elif 2 * standard_distance < distance <= 3 * standard_distance:
        return 8
    elif 3 * standard_distance < distance <= 4 * standard_distance and has_green_pixel_in_11x11_region(inImg,x,y):
        return 7
    elif 4 * standard_distance < distance <= 5 * standard_distance and has_green_pixel_in_11x11_region(inImg,x,y):
        return 6
    elif 5 * standard_distance < distance <= 6 * standard_distance and has_green_pixel_in_11x11_region(inImg,x,y):
        return 5
    return 0

def has_green_pixel_in_11x11_region(testImg,x, y):
    """
    判断给定点(x, y)周围11x11区域是否有绿色像素。

    参数:
    x (int): 目标像素点的x坐标。
    y (int): 目标像素点的y坐标。

    返回:
    bool: 如果11x11区域内存在绿色像素，则返回True，否则返回False。
    """
    # 确保坐标不会超出图像边界
    x_start = max(0, x - 5)
    x_end = min(x_start + 11, testImg.shape[1])
    y_start = max(0, y - 5)
    y_end = min(y_start + 11, testImg.shape[0])

    # 获取7x7区域的HSV图像
    region_hsv = testImg[y_start:y_end, x_start:x_end]

    # 定义绿色的HSV范围
    lower_green = np.array([40, 40, 40])
    upper_green = np.array([80, 255, 255])

    # 创建绿色像素的掩码
    mask = cv2.inRange(region_hsv, lower_green, upper_green)

    # 检查掩码中是否存在非零元素（即绿色像素）
    return np.any(mask)


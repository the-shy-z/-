#导入所需要的库
import cv2
import numpy as np
import img_prc.judge_rings
import img_prc.bullet_hole_detect
from img_prc.filter import apply_closing_application,apply_gaussian_blur,apply_opening_operation  #过滤文件
from img_prc.circle import detect_and_average_circles  #检测圆形文件
from img_prc.judge_rings import judge_rings,has_green_pixel_in_11x11_region  #判断环文件
from img_prc.bullet_hole_detect import  Combined_filtering,Mean_difference,Reconstruction_image,Bullet_hole_coordinates,apply_closing_application2,liantong #弹孔检测文件
from img_prc.recommendation import process_input,calculate_variance_and_direction,evaluate_performance_refined
from img_prc.utils import start, Image_correction, order_points_simple





def img_process(image_path):
    img = cv2.imread(image_path,1)
    nor_size=1200
    img1=img.copy()
    if img is None:
        raise ValueError("Image not found or unable to load.")
    image_hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    #对靶面进行提取，畸变校正
    # filter_img = apply_gaussian_blur(apply_closing_application(apply_opening_operation(img)))
    dot=start(img)
    # dot = order_points_simple(dot)
    # dot[-1], dot[-2] = dot[-2], dot[-1]
    # print(dot)

    # dot = np.array(dot, dtype=np.int32)
    # mask = np.zeros_like(img)
    #
    # cv2.fillPoly(mask, [dot], (255, 255, 255))
    # result = cv2.bitwise_and(img, mask)
    # result[result == 0] = 255
    img,M,w,h= Image_correction(img,dot)
    cv2.imwrite("C:/photo/8.jpg",img)


    #提取靶面中心和10环半径
    center,radius = detect_and_average_circles(img)

    #提取弹孔点中心


    width = img1.shape[0]
    height = img1.shape[1]

    img1 = Combined_filtering(img1, 3)  # 组合滤波

    img1 = Mean_difference(img1, -0.28)  # 计算平均差量矩阵

    img1 = Reconstruction_image(width, height, img1)  # 重建图像

    img1 = apply_closing_application2(img1, 3)  # 闭运算
    cv2.imwrite("C:/photo/000.jpg", img1)

    warped = cv2.warpPerspective(img1, M, (w, h))
    warped = cv2.resize(warped, (nor_size, nor_size))

    cv2.imwrite("C:/photo/00.jpg",warped)
    warped = liantong(warped)  # 连通域处理
    cv2.imwrite("C:/photo/0.jpg", warped)
    count,bullet_hole = Bullet_hole_coordinates(warped)  # 保存弹孔坐标
    print(count)
    print(bullet_hole)
    #统计成绩以及计算环数
    grade = []
    for i in range(count):
        grade.append(judge_rings(warped,bullet_hole[i][0],bullet_hole[i][1],center[0],center[1],radius))
    total_grade = sum(grade)
    print(grade)
    #给出射击建议
    variance,mean_direction_deviation = calculate_variance_and_direction(bullet_hole,center)
    suggestion = evaluate_performance_refined(total_grade,variance,mean_direction_deviation)
    return grade,total_grade,suggestion

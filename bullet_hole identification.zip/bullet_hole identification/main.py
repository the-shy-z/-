import sys
import pymysql
from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox
from PyQt5 import QtWidgets
from UI.login import Ui_MainWindow as Ui_LoginWindow
from UI.detect import Ui_DetectWindow
from UI.Register import Ui_RegisterForm



# 定义一个名为LoginWindow的类，继承自QMainWindow和Ui_LoginWindow。
class LoginWindow(QMainWindow, Ui_LoginWindow):
   def __init__(self):
       # 初始化LoginWindow类，设置UI界面，并连接信号和槽。
       super().__init__()
       self.setupUi(self)
       self.login_pushButton.clicked.connect(self.login)
       self.register_pushButton.clicked.connect(self.show_register_window)

   def login(self):
       # 登录功能，连接数据库，验证用户名和密码。
       # 如果验证成功，显示检测窗口，否则显示错误提示。
       conn = pymysql.connect(host='localhost', port=3306, user='root', password="123456", db="target_reporting_system_usr")
       cur = conn.cursor()

       try:
           user_name = self.username_lineEdit.text()
           password = self.password_lineEdit.text()

           sql = "SELECT user_name FROM user WHERE user_name = %s AND password = %s"
           cur.execute(sql, (user_name, password))
           data = cur.fetchone()

           if data:
               print(f"用户 {data[0]} 登录成功")
               self.show_detect_window()
           else:
               QMessageBox.warning(self, '错误', '用户名或密码不正确。')

       except Exception as e:
           print(f"发生错误: {e}")
           QMessageBox.critical(self, '错误', str(e))

       finally:
           cur.close()
           conn.close()

   def show_detect_window(self):
       # 创建并显示检测窗口。
       self.detect_window = DetectWindow()
       self.detect_window.show()
       self.close()

   def show_register_window(self):
       # 创建并显示注册窗口。
       self.register_window = RegisterWindow(self)
       self.register_window.show()
       self.close()



# 定义一个名为DetectWindow的类，继承自QMainWindow和Ui_DetectWindow。
class DetectWindow(QMainWindow, Ui_DetectWindow):
   def __init__(self):
       # 初始化DetectWindow类，设置UI界面。
       super().__init__()
       self.setupUi(self)


# 定义一个名为RegisterWindow的类，继承自QMainWindow和Ui_RegisterForm
class RegisterWindow(QMainWindow, Ui_RegisterForm):
    # 定义构造函数，参数为一个login_window对象
    def __init__(self, login_window):
        # 调用父类的构造函数
        super().__init__()
        # 将login_window赋值给self.login_window
        self.login_window = login_window
        # 调用setupUi方法设置UI界面
        self.setupUi(self)

        # 确保获取所有必要的输入控件引用
        self.username_lineEdit = self.findChild(QtWidgets.QLineEdit, "username_lineEdit")
        self.password_lineEdit = self.findChild(QtWidgets.QLineEdit, "password_lineEdit")
        self.telephone_number_lineEdit = self.findChild(QtWidgets.QLineEdit, "telephone_number_lineEdit")  # 添加这一行

        # 获取注册按钮，并连接点击事件到register_user方法
        self.register_pushButton = self.findChild(QtWidgets.QPushButton, "register_pushButton")
        if self.register_pushButton:
            self.register_pushButton.clicked.connect(self.register_user)
        else:
            print("Error: register_pushButton not found in UI.")

    # 定义register_user方法
    def register_user(self):
        # 获取用户输入的用户名、密码和电话号码
        username = self.username_lineEdit.text()
        password = self.password_lineEdit.text()
        telephone_number = self.telephone_lineEdit.text()  # 获取电话号码

        # 使用pymysql.connect连接数据库
        try:
            with pymysql.connect(host='localhost', port=3306, user='root', password="123456",
                                 db="target_reporting_system_usr") as conn, \
                    conn.cursor() as cursor:

                # 查询用户名是否已存在
                check_sql = "SELECT COUNT(*) FROM user WHERE user_name = %s"
                cursor.execute(check_sql, (username,))
                result = cursor.fetchone()
                if result[0] > 0:
                    # 如果用户名已存在，则提示用户并结束函数
                    QMessageBox.warning(self, '警告', '用户名已存在，请选择其他用户名！')
                    return

                # 用户名不存在，执行插入操作
                sql = "INSERT INTO user (user_name, password, telephone_number) VALUES (%s, %s, %s)"
                cursor.execute(sql, (username, password, telephone_number))
                conn.commit()

                # 显示注册成功提示
                QMessageBox.information(self, '成功', '注册成功！')
                # 关闭注册窗口
                self.close()
                # 显示登录窗口
                self.login_window.show()

        # 捕获异常
        except Exception as e:
            # 显示注册失败提示
            QMessageBox.critical(self, '错误', f'注册失败: {str(e)}')
            # 打印异常信息
            print(f"注册时发生错误: {str(e)}")


if __name__ == '__main__':
    app = QApplication(sys.argv)
    login_window = LoginWindow()
    login_window.show()
    sys.exit(app.exec_())